# ==============================================
# Lab Assignment 4 - String Manipulation (Q10–Q11)
# ==============================================

# Q10: Palindrome Rearrangement Checker
def palindrome_checker(s):
    # TODO:
    # - Return "Yes" if string can be rearranged into a palindrome
    # - Return "No" otherwise
    # - Return "input invalid" for empty or non-string
    pass
    if not isinstance(s, str) or s == '':
        return "input invalid"
    if len(s)%2==0:
        k = []
        for i in s:
            if s.count(i)%2==0:
                    k.append(i)
        if len(k)==len(s):
            return "yes"
        else:
            return "No"


    elif len(s)%2!=0:
        j = []
        for i in s:
            if s.count(i)%2!=0:
                if i not in j:
                    j.append(i)
        if len(j) == 1:
            return "Yes"
        else:
            return "No"



# Q11: String Rotation Validator
def rotation_checker(s1, s2):
    # TODO:
    # - Return True if s2 is a rotation of s1
    # - Return False otherwise
    # - Return "input invalid" if inputs are not strings or lengths differ
    pass
    if not isinstance(s1,str) or not isinstance(s2,str) or len(s1) != len(s2) :
        return "input invalid"
    j =[]
    for n in range(len(s1)):
        if s1 == s2[n:] + s2[:n]:
            j.append(n)
    if j != []:
        return True
    else:
        return False