# ==============================================
# Lab Assignment 4 - Time Complexity (Q7–Q9)
# ==============================================
import time

# Hint:
# Try plotting the time complexity data with matplotlib to visualize growth trends
# Will help in identifying the expected time complexity class

# ---------- Q7 ----------
def func1(n):
    s = 0
    for _ in range(n):
        j = 1
        while j * j <= n:
            s += 1
            j += 1
    return s

def analyze_func1():
    """
    TODO:
    - Pick at least 3 n values
    - Measure runtime for each n and store in a dict {n: time}
    - Return (dict, "Estimated Complexity: O(?)")
    """
    # Example skeleton (replace with your own n's):
    # times = {}
    # for n in [ ... ]:
    #     Evalute func1(n) and measure time taken
    # return times, "Estimated Complexity: O(?)"
    pass
    times = {}
    for n in [100022, 3203, 50000, 2000, 4321]:
        start_time = time.time()
        func1(n)
        end_time = time.time()
        times[n] = end_time - start_time
    return times, "Estimated Complexity: O(n^1.5)"

# ---------- Q8 ----------
def func2(n):
    for _ in range(n):
        for _ in range(n):
            k = 1
            while k < n:
                k *= 2

def analyze_func2():
    """
    TODO: same pattern as analyze_func1
    """
    pass
    import time
    times = {}
    for n in [10, 320, 5000, 2004, 4320]:
        start_time = time.time()
        func2(n)
        end_time = time.time()
        times[n] = end_time - start_time
    return times, "Estimated Complexity: O((n^2)log n)"


# ---------- Q9 ----------
def func3(n):
    if n <= 1:
        return 1
    return func3(n-1) + func3(n-1)

def analyze_func3():
    """
    TODO: same pattern as analyze_func1
    """
    pass
    import time
    times = {}
    for n in [10, 15, 5, 25]:
        start_time = time.time()
        func3(n)
        end_time = time.time()
        times[n] = end_time - start_time
    return times, "Estimated Complexity: O(2^n)"
